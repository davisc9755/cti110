# Define your function here.
def days_in_feb(user_year):
   if user_year % 4 == 0:
       if user_year % 100 == 0:
           if user_year % 400 == 0:
               return 29
           else:
               return 28
       else:
           return 29
   else:
       return 28
if __name__ == '__main__':
    # Type your code here. Your code must call the function.
     input_year = int(input())
     days = days_in_feb(input_year)
     print(input_year , "has", days ,"days in February.")