''' Type your code here. '''
# get miles and the cost

mileage = float (input())

gas_price = float (input())

# calculate cost per mile

cost_20 = 20/mileage * gas_price

cost_75 = 75/mileage * gas_price

cost_500 = 500/mileage * gas_price

print(f'{cost_20:.2f} {cost_75:.2f} {cost_500:.2f}')